<?php
require 'vendor/autoload.php';
$data = [
    'seller_name' => $_POST['seller_name'], 
    'buyer_name'  => $_POST['buyer_name'], 
    'street_address' => $_POST['street_address'],
    'location'  => $_POST['location'], 
    'tax_id'  => $_POST['tax_id'], 
    'offer_price'  => $_POST['offer_price'], 
    'escrow_agent_name'  => $_POST['escrow_agent_name'],
    'escrow_agent_email'  => $_POST['escrow_agent_email'],
    'escrow_agent_address'  => $_POST['escrow_agent_address'],
    'escrow_agent_phone'  => $_POST['escrow_agent_phone'],
    'escrow_agent_fax'  => $_POST['escrow_agent_fax'],
    'buyer_name_end'  => $_POST['buyer_name'], 
    'seller_name_end'  => $_POST['seller_name'], 
    'current_date'  => $_POST['current_date'], 
    'cooperating_sales_agent'  => $_POST['cooperating_sales_agent'],
    'cooperating_broker_agent'  => $_POST['cooperating_broker_agent'],
    'legal_description'  => "                 ".$_POST['legal_description'], 
    'podio_item_id' => $_POST['podio_item_id'],   
    'web_hook_url' => $_POST['web_hook_url'],    
];
$filename = 'AS-IS-Contract_' . rand(2000,1200000) . '.pdf';

if($data){
    $pdf = Zend_Pdf::load('AS IS Contract.pdf');
    $pdf->setTextField("seller",$data['seller_name']);
    $pdf->setTextField("buyer", $data['buyer_name']);
    $pdf->setTextField("street_address", $data['street_address']);
    $pdf->setTextField("tax_id", $data['tax_id']);
    $pdf->setTextField("legal_description", $data['legal_description']);
    $pdf->setTextField("escrow_name", $data['escrow_agent_name']);
    $pdf->setTextField("escrow_address", $data['escrow_agent_address']);
    $pdf->setTextField("escrow_phone", $data['escrow_agent_phone']);
    $pdf->save($filename);
}
function doPostRequesttoWebHook($data,$filename){
    try{
    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => $data['web_hook_url'],
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS => array('Buyer'=>$data['buyer_name'],'Seller'=>$data['seller_name'],'podio_item_id'=>$data['podio_item_id'],'file'=> new CURLFILE(realpath($filename))),
      CURLOPT_HTTPHEADER => array(
        'Cookie: AWSALB=1ijjNtQoptaDXu43CxKqIZjVlgQufrLwGRyurUvz+z5IASzykYk9RUzCbQD2ChMuPvJu/nzYu6rwRvfupUw29woNzIPUATQCKfR84N0ojMl1ecAndtEVyhQAp7qx; 
        AWSALBCORS=1ijjNtQoptaDXu43CxKqIZjVlgQufrLwGRyurUvz+z5IASzykYk9RUzCbQD2ChMuPvJu/nzYu6rwRvfupUw29woNzIPUATQCKfR84N0ojMl1ecAndtEVyhQAp7qx; 
        PHPSESSID=7d677eac59656754f4e9822a43c0b0d2'
      ),
    ));
    $response = curl_exec($curl);
    $request_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);
     if($request_status==200){
        unlink(realpath($filename));
     }
    } catch(Exception $e){
          print("<pre>");
          print_r($e);
    }
}

if($pdf){
doPostRequesttoWebHook($data,$filename);
}
?>